
print('Program written by: Amy Ho')
print('Name: CNET 142 - Ron Sha Lab 5 file counter')
print('Program: file_counter.py')
import datetime
now = datetime.datetime.now()
print("Current time: ", now.strftime("%y-%m-%d %H:%M:%S"))


f = open("test.txt", "r")
print(f.read())


# Opening file
file1 = open("test.txt", 'r')
lcount = 0
wcount = 0
linetrim = ""
characters = 0
lineList = list()

# Using for loop
print("Using for loop")
for line in file1:
    lcount += 1
    linetrim = line.rstrip('\r\n')
    wcount += len(linetrim.split())
    characters += len(linetrim)

    print("Line{}: {}".format("count", line.strip()))
    lineList.append(line.strip())


#Closing Files
file1.close()

print("Total number of lines: ", len(lineList))
print("Total number of words: ", wcount)
print("Total number of characters: ", characters)




#Total number of Uppercase Letters
letters = set()
with open('test.txt') as countletter:
    count = 0
    text = countletter.read()
    for character in text:
        if character.isupper():
            count += 1
            letters.add(character)
    print("Total number of uppercase letters: ", count)


#Total number of Lowercase Letters
letters = set()
with open('test.txt') as countletter:
    count = 0
    text = countletter.read()
    for character in text:
        if character.islower():
            count += 1
            letters.add(character)
    print("Total number of lowercase letters: ", count)

#Total number of spaces
spaces = set()
spaces = 0
with open('test.txt') as countspaces:
    for character in text:
        text = countspaces.read()
        if character.isspace():
            spaces += 1
            letters.add(spaces)
        else:
            pass
    print("Total number of spaces: ", spaces)


#Total number of digits
digits = set()
digits = 0
with open('test.txt') as countdigit:
    text = countdigit.read()
    for character in text:
        if character.isdigit():
            digits = digits + 1
            letters.add(digits)
        else:
            pass
    print("Total number of digits: ", digits)


#Total number of sentences
with open('test.txt', 'r') as file:
    file_contents = file.read()
    print('Total number of sentences: ', file_contents.count('.'))
