
print('Name: Amy Ho - CNET 142 - Lab 6 Dictionary')
print('Program: dictionaryLab6_working.py')
import datetime
import json


now = datetime.datetime.now()
print("Current Time: ")
print(now.strftime("%y-%m-%d %H:%M:%S"))


def create_my_contact():
    my_contact = {}
    my_contact = {'01': {'firstName': "John", 'lastName': "Smith", 'DOB': "1/20/1991",
                         'phoneNum': {'home': "510-600-5400", 'type': "cell"},
                         'address': {'street': "100 main street", 'city': "Fremont", 'state': "CA", 'zipcode': 94536}},
                  '02': {'firstName': "Ron", 'lastName': "Robertson", 'DOB': "5/23/1991",
                         'phoneNum': {'home': "510-600-8800", 'type': "cell"},
                         'address': {'street': "4600 Ohlone Way", 'city': "Fremont", 'state': "CA", 'zipcode': 94536}},
                  '03': {'firstName': "Paul", 'lastName': "Washington", 'DOB': "6/15/1995",
                         'phoneNum': {'home': "510-688-1241", 'type': "cell"},
                         'address': {'street': "8543 Ohlone Plaza", 'city': "Fremont", 'state': "CA",
                                     'zipcode': 94536}}}
    return my_contact


a_contact = create_my_contact()
 # print(a_contact)



def save_json_file(fileName, contact_list):
  with open(fileName, 'w') as write_file:
    json.dump(contact_list, write_file)


# save_json_file("my_contact.json", a_contact)


def open_json_file( filename):
  with open(filename,'r') as json_data:
    data = json.load(json_data)
    return data


def find_my_contact_key(searchKey, my_contact):
  print("*** Searching for " + searchKey)
  for p_pid, p_info in my_contact.items():
      for key in p_info:
          if( key=='firstName'):
              if(p_info[key]==searchKey):
                  print ("*** " + searchKey + " Fo und ***")
                  print(p_info)
                  return
  print ("*** " + searchKey + " Not found ***")
  return


contact_list = create_my_contact()
save_json_file("my_contact.json", contact_list)

json_data={}
json_data = open_json_file('my_contact.json')
print("***BEGINNING OF JSON List: \n", contact_list, "\n ***END OF JSON LIST: \n\n")

print(json_data)

find_my_contact_key("Ron", json_data)
find_my_contact_key("Sha", json_data)













