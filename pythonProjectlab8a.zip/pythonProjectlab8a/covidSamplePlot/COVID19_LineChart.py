#
#https://matplotlib.org/3.1.1/api/_as_gen/matplotlib.pyplot.xlabel.html#matplotlib.pyplot.xlabel
#
import matplotlib.pyplot as plt
import numpy as np


import csv

Axlist = []
Aylist = []


with open('COVID19_Alameda.csv','r') as csvfile:
    plots = csv.reader(csvfile, delimiter=',')
    for row in plots:
        Axlist.append(row[0])
        Aylist.append(int(row[2]))

plt.plot(Axlist,Aylist, label='Alameda')



ax = plt.gca() # get current axes
# rotate the label x degree, see what happens if you change rotation
plt.xticks(rotation=0, fontsize=8) 
# only print out every other x label so it will fit
# If remove the for loop, labels will overlap each other
# try different ::tNum to see what happens
tNum = 6
for label in ax.get_xaxis().get_ticklabels()[::tNum]:
    label.set_visible(False)


# Add labels to line plots (annotation)
# zip joins x and y coordinates in pairs
#
def annatationLabel(xlist, ylist):
    count = 0 # used to only plot out annatation for every other number
    for x,y in zip(xlist,ylist):
        # for odd number: count %2 > 0; or use count to control
        # when to put annatation so it doesn't overlap
        everyNum = 1
        if (count == everyNum):  # print out every everyNum number, you can 
    #    if (count %2) > 0: # this is odd number
#            label = "{:.2f}".format(y)
            label = (int)(y)
            plt.annotate(label, # this is the text
                         (x,y), # this is the point to label
                         textcoords="offset points", # how to position the text
                         xytext=(0,10), # distance from text to points (x,y)
                         ha='center') # horizontal alignment can be left, right or center
            count = 0
        else:
            count = count + 1


def alamedaChart():
    plt.xlabel('Date', fontsize=8)
    plt.ylabel('# of Cases')
    plt.title('Bay Area COVID19 Stats')
    annatationLabel(Axlist, Aylist)
    plt.legend()
    plt.show()

if __name__ == '__main__':
    alamedaChart()
