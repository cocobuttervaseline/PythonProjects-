
print('CNET-142: Amy Ho - Lab 2: Car Efficiency')
import datetime
now = datetime.datetime.now()
print(now.strftime("%y-%m-%d %H:%M:%S"))


capacityOfCarGasTank = float(input("Enter the capacity of the car's gas tank(in gallons): "))
miles_per_gallon = float(input("Enter car's miles per gallon: "))
price_per_gallon = float(input("Enter price per gallon: "))
Cost = 100/miles_per_gallon*price_per_gallon
Distance = capacityOfCarGasTank*miles_per_gallon

Cost_float = Cost
Cost_float = "{:.2f}".format(Cost_float)

Distance_float = Distance
Distance_float = "{:.2f}".format(Distance_float)

print("Cost for driving 100 miles is $" + str(Cost_float))
print("Distance on a tank of gas is " + str(Distance_float) + " miles ")

