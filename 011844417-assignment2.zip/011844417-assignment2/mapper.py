#Name: Amy Ho
#SID: 011844417
#Class: INFM 203-10
# Professor Jain

import sys
import re
pattern = re.compile("^[a-z]+$") # matches purely alphabetic words
for line in sys.stdin:
    line = line.strip()
    tokens = line.split()
    for token in tokens:
        lowercaseword = token.lower()
        lowercaseword = re.sub(r"[^a-z0-9]", "", lowercaseword)
        if pattern.match(lowercaseword):
            letters = list(lowercaseword)
            #print('%s 1' % lowercaseword)
            for i in range(len(letters)):
                if i == 0 and len(letters) == 1 and letters[i] in ('a', 'e', 'i', 'o', 'u'):
                    print ("%c\t1\t1\t1" % letters[i])
                elif i == len(letters) - 1 and len(letters) > 1 and letters[i] in ('a', 'e', 'i', 'o', 'u'):
                    print ("%c\t1\t0\t1" % letters[i])
                elif i == 0 and len(letters) > 1 and letters[i] in ('a', 'e', 'i', 'o', 'u'):
                    print ("%c\t1\t1\t0" % letters[i])
                else:
                    print ("%c\t1\t0\t0" % letters[i])