#Name: Amy Ho
#SID: 011844417
#Class: INFM 203-10
# Professor Jain


from itertools import groupby
from operator import itemgetter
import sys

def read_mapper_output(file):
    for line in file:
        yield line.strip().split('\t')
        #yield line.strip().split(' ')

data = []
for vec in read_mapper_output(sys.stdin):
    tup = tuple(vec)
    data.insert(0, tup)

sorted_data = sorted(data)

for key, grp in groupby(sorted_data, itemgetter(0)):
    for thing in grp:
        print("%s\t%s\t%s\t%s" % (key, thing[1], thing[2], thing[3]))



#data = read_mapper_output(sys.stdin)


#print(' '.join(list(data)))
#for key, keygroup in groupby(data, itemgetter(0)):
   # values = ' '.join(sorted(v for key, v in keygroup))
   # print("%s %s" % (key, values))
