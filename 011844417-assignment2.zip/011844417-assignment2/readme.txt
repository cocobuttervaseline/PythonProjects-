Amy Ho 
SID: 011844417
INFM 203-10: Big Data Analytics 
Professor Jain 
05/06/2023

Assignment 2: 

General Description: 
Run a text file through the MapReduce framework to calculate the number of times each alphabet appears in the text file, how many times a vowel appears as the first letter of a word  , and how many times a vowel appears as the last letter of a word. 


List of Files: 
Input test text file - test.txt 
Source Code Python files - mapper.py, group-by-key.py, reducer.py 
Screenshot Output files for each source code python file - DisplayInputTextFile.png, mapper_output.png, sort_output.png, compare_sort_groupbykey_outputs.png, groupbykey_output.png, reducer_output.png 



How to run: 
1) cat test.txt 
2) cat test.txt | python3 mapper.py 
3) cat test.txt | python3 mapper.py | sort 
4) cat test.txt | python3 mapper.py | sort | python3 group-by-key.py 
5) cat test.txt | python3 mapper.py | python3 group-by-key.py 
6) cat test.txt | python3 mapper.py | python3 group-by-key.py | python3 reducer.py 





Mapper.py 

Code Description: 
The program processes the input text file and determines the content of the text file in three different categories - written in lines 13-21. Lines 13-14 prints a tab-separated string for each character which indicates whether the character is a vowel and whether it is a first or last letter of a word. The first category condition is, if the character is the only character in the word and is a vowel, it is printed as a vowel in the first and last position. The second category condition is, if the character is the last character in the word and is a vowel, it is printed as a vowel in the last position only. The third category condition is, if the character is the first character in the word and is a vowel, it is printed as a vowel in the first position only. Otherwise, the character is printed as a consonant. 

Output Description: 
The output consists of a tab separated string containing the letter, the number 1 to indicate that this letter is counted once and the three different categories  - (1) if letter is the first letter of a word; (2) if letter is the last letter of a word; (3) if letter is a vowel. 0 stands for false and 1 stands for true which represents if the condition for each category is met or not. The first category is 1 if the letter is the first letter of the word and 0 if otherwise; the second category is 1 if the letter is the last letter of the word and 0 if otherwise; the third category is 1 if the letter is a vowel and 0 if otherwise. 




Group-by-key.py 

Code Description: 
Lines 11-14 first, creates an empty list 'data' and loops the mapper.py output and passes it into sys.stdin as an argument. Then, each line of the text file is packed into tuple which are then inserted in the beginning of the 'data' list which reverses the order of the text file lines. Line 16 sorts the list 'data' in ascending order. Since 'data' was reversed earlier in lines 11-14, line 16 sorts the lines in descending order. Lines 18-20 uses the 'groupby' function to group the sorted data by the key to its value (key-value pair). 

Output Description: 
The output from mapper.py is piped into the Group-by-key.py code. The group-by-key.py program functions the same as the sort command therefore the sort command is not needed. The output of the group-by-key.py code consists of letters grouped together in alphabetical order and in which each letter meets the three different category conditions as listed above in its respective order - as represented by a 1 or 0 for True or False. 




Reducer.py 

Code Description: 
Three dictionaries are created: 'LetterCount', 'FirstVowelCount', and 'LastVowelCount', each with initial values of 0 for each key. 'LetterCount' is used to count the total number of occurrences of each letter, while 'FirstVowelCount' and 'LaastVowelCount' is used to count the number of times each vowel appears as the first or last letter of a word respectively. From lines 14-23 - these lines loop over the output from the group-by-key.py code when it is passed into 'sys.stdin' as an argument. For each line in the text file, the first letter ie extracted and used to update the corresponding count in 'LetterCount'. If the letter is a vowel and the third field of the text file is 1, (indicating that the letter his the first letter of a word), the corresponding count in 'FirstVowelCount' is updated. If the letter is a vowel and the fourth field of the input is 1 (indicating that the letter is the last letter of a word), the corresponding count in 'LastVowelCount' is updated. 


Output Description: 
The output from the group-by-key.py code is piped into the reducer.py code. The reducer.py code defines three dictionaries: 'LetterCount', 'FirstVowelCount', and 'LastVowelCount'. These dictionaries are used to store the counts of letters, first vowels, and last vowels respectively. The keys in these dictionaries are the 26 letters of the alphabet and the values are initialized to  0. For each line in the text file, the function extracts the letter from the first field of the list and increments the count for that letter in the 'LetterCount' dictionary. If the letter is a vowel, and the second field of the list indicates that the letter is the first letter in the word, the function increments the count for that vowel in the 'FirstVowelCount' dictionary. If the letter is a vowel and the third field of the list indicates the letter is the last letter of a word, the function increments the count for that vowel in the 'LastVowelCount' dictionary. Finally, the function loops through the 'LetterCount' dictionary and prints out the counts of each letter, along with the counts of first and last vowels for each vowel. If a letter is not a vowel, the counts of the first and last vowels for that letter are set to 0.
































































