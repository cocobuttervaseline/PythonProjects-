#Name: Amy Ho
#SID: 011844417
#Class: INFM 203-10
# Professor Jain

import sys

def read_mapper_output(file):
    for line in file:
        yield line.strip().split('\t')

LetterCount = dict()
LetterCount = {'a':0, 'b':0, 'c':0, 'd':0, 'e':0, 'f':0, 'g':0, 'h':0, 'i':0, 'j':0, 'k':0, 'l':0, 'm':0, 'n':0, 'o':0, 'p':0, 'q':0, 'r':0, 's':0, 't':0, 'u':0, 'v':0, 'w':0, 'x':0, 'y':0, 'z':0 }
FirstVowelCount = dict()
FirstVowelCount = {'a':0, 'e':0, 'i':0, 'o':0, 'u':0}
LastVowelCount = dict()
LastVowelCount = {'a':0, 'e':0, 'i':0, 'o':0, 'u':0}

for vec in read_mapper_output(sys.stdin):
    letter = vec[0]
    #print(letter, vec[1], vec[2], vec[3])

    LetterCount[letter] = LetterCount[letter] + 1

    if letter in ('a', 'e', 'i', 'o', 'u') and int(vec[2]) == 1:
        FirstVowelCount[letter] = FirstVowelCount[letter] + 1
    if letter in ('a', 'e', 'i', 'o', 'u') and int(vec[3]) == 1:
        LastVowelCount[letter] = LastVowelCount[letter] + 1

for letter, count in LetterCount.items():
  if letter in ('a', 'e', 'i', 'o', 'u'):
    print(letter, count, FirstVowelCount[letter], LastVowelCount[letter])
  else:
      print(letter, count, 0, 0)





    #print(LetterCount.keys(), LetterCount.values())
#for letter in FirstVowelCount:
    #print(FirstVowelCount.keys(letter), FirstVowelCount.values(letter))
#for letter in LastVowelCount:
    #print(LastVowelCount.keys(letter), LastVowelCount.values(letter))










   # totalalphacount = sum(int(number) for number in vec[1])
  #  print("%s %d" % (letter, totalalphacount))
   # totalfirstvowel = sum(int(number) for number in vec[2])
   # print("%s %d" % (letter, totalfirstvowel))
   # totallastvowel = sum(int(number) for number in vec[3])
   # print("%s %d" % (letter, totallastvowel))
    #count = sum(int(number) for number in vec[1:])
