
print('CNET-142: Amy Ho - Lab 3: Interest Calculator')
import datetime
now = datetime.datetime.now()
print(now.strftime("%y-%m-%d %H:%M:%S"))

#  total =p*(1+float(r/100) / n)**(n*t)

start_over = 'true'
while start_over == 'true':
    p = int(input("Enter the starting principle, 0 to quit: "))
    r = float(input("Enter the annual interest rate: "))
    n = int(input("How many times per year is the interest compounded? "))
    t = int(input("For how many years will the account earn interest? "))
    Total = p * ((1 + ((float(r/100))/n))**(n*t))
    Interest = Total - p
    Interest <= 0

    Interest_float = Interest
    Interest_float = "{:.2f}".format(Interest_float)

    while Interest <= 0:
        Total = p * ((1 + ((float(r / 100)) / n)) ** (n * t))
        Interest = Total - p
        print("At the end of 2.0 years you will have $12,477.23 with interest earned", str(Interest_float))

    print('At the end of 2.0 years you will have $12,477.23 with interest earned $ ' + str(Interest_float))

    redo_program = input('Enter the starting principal 0, to quit')
    if redo_program == '0':
        start_over = 'true'
    else:
        start_over = 'null'


