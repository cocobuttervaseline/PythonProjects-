
def loanCalcButtonClick(self):
    if (self.LCD is None) :
            self.LCD = LoanCalculator()
    else:
        if (self.LCD.winfo_exists()):
            self.LCD.focus()
        else:
            self.LCD = LoanCalculator()


def __init__(self, parent):
    Frame.__init__(self, parent)
    self.parent = parent
    self.LCD = None  # Loan calculator object
    self.initUI()







from LoanCalculator import Frame
