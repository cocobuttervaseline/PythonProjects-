


from tkinter import *
from tkinter.ttk import Frame, Button, Label, Entry, Style
from tkinter import BOTH, END, messagebox
import sys
class LoanCalculator(Toplevel):

    def __init__(self, parent):
        Frame.__init__(self, parent)
        self.parent = parent
        self.LCD = None                        #Mortgage Calculator Object

    def initUI(self):
        self.title("Mortgage Calculator")
        self.geometry("300x300")
        self.style = Style()
        self.style.theme_use("default")        #default

        #self.pack(fill=BOTH, expand=1)

        xpos = 40
        ypos = 30
        xpos2 = xpos+100
        l1 = Label(self, text="Loan Amount", foreground="#ff0000", background="light blue ", font="Arial 14")          #Arial 14 bold italic
        l1.place(x=xpos, y=ypos)
        self.txtLoanAmount = Entry(self)
        self.txtLoanAmount.place(x=xpos2, y=ypos, width=70)

        ypos += 30

        l2 = Label(self, text="Interest Rate %: ", foreground="#ff0000", background="light blue", font="Arial 14")      #Arial 14 bold italic
        l2.place(x=xpos, y=ypos)
        self.txtInterestRate = Entry(self)
        self.txtInterestRate.place(x=xpos2, y=ypos)

        ypos += 30
        l3 = Label(self, text="Loan Term (Years) ", foreground="#ff0000", background="light blue", font="Arial 14")     #Arial 14 bold italic
        l3.place(x=xpos, y=ypos)
        self.txtLoanTerm = Entry(self)
        self.txtLoanTerm.place(x=xpos2, y=ypos)

        ypos += 30
        l4 = Label(self, text="Monthly Payment: ", foreground="#ff0000", background="light blue", font="Arial 14")      #Arial 14 bold italic
        l4.place(x=xpos, y=ypos)
        self.txtMonthlyPayment = Entry(self)
        self.txtMonthlyPayment.configure(state="readonly")
        self.txtMonthlyPayment.place(x=xpos2, y=ypos)

        ypos += 30
        l5 = Label(self, text="Total Paid: ", foreground="#ff0000", background="light blue", font="Arial 14")           #Arial 14 bold italic
        l5.place(x=xpos, y=ypos)
        self.txtTotalPaid = Entry(self);
        self.txtTotalPaid.configure(state="readonly")
        self.txtTotalPaid.place(x=xpos2, y=ypos)

        ypos += 30
        style = Style()
        style.configure("Quit.TButton", foreground="gray", background="green")

    #T.Checkbutton for checkboxes
        style.configure("MainButton.TButton", foreground="gray", background="green")
        quitButton = Button(self, text="Quit", command=self.quitButtonClick)
        quitButton.configure(style="Quit.Button")
        quitButton.place(x=xpos, y=ypos)

        calcButton = Button(self, text="Calculate", command=self.calcButtonClick)
        calcButton.configure(style="MainButton.TButton")
        calcButton.place(x=xpos2, y=ypos)

        def quitButtonClick(self):
            if (messagebox.askofcancel("Ok to close?", "Close application?")):
                self.parent.destroy
                exit()                                                                                                  # needed to close the main frame

        def calcButtonClick(self):
            amt = float(self.txtLoanAmount.get())
            rate = float(self.txtInterestRate.get())
            dur = float(self.txtLoanTerm.get())
            monthlyPayment = amt * (rate/1200.0) * ((rate/1200 + 1)** dur)/ (((rate/1200 +1)** dur) -1)
            totalPaid = amt * ((1 + rate/1200)** dur);

            self.txtMonthlyPayment.configure(state="normal")                                                            # has to be turned back to normal otherwise, data is not modified
            self.txtMonthlyPayment.delete(0, END)
            self.txtMonthlyPayment.insert(0, format(monthlyPayment, "0.2f"))
            self.txtMonthlyPayment.configure(state="readonly")

            self.txtTotalPaid.configure(state="normal")
            self.txtTotalPaid.delete(0, END)
            self.txtTotalPaid.insert(0, format(totalPaid, "0.2f"))
            self.txtTotalPaid.configure(state="readonly")